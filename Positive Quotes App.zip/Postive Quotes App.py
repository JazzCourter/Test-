"""
Author: Jazz Courter
Date Written: 12/4/25
Assignment: Final Project
This program is designed to generate a positive quote, and allow users to store their favorites.
"""
"""Positive Quotes"""

"""Module 1: Defines 1st Window"""

import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import random

class PositiveQuotesApp:
    def __init__(self, root):
        self.root = root
        # App Title Label
        self.root.title("Daily Inspiration")
        # Format Title
        self.app_title_label = tk.Label(self.root, text="Positive Quotes", font=("Arial", 24, "bold"))
        self.app_title_label.pack(pady=10)
        # Generate text box
        self.daily_quote_text = tk.Text(self.root, height=5, width=50, wrap=tk.WORD)
        self.daily_quote_text.pack()
        self.update_quote()
        # Create space for buttons
        self.button_frame = tk.Frame(self.root)
        self.button_frame.pack(pady=10)
        # Create Save Button
        self.favorite_quote_button = tk.Button(self.button_frame, text="Save to Favorites", command=lambda: add_quote_to_favorite_quotes(self.daily_quote_text), bg="green", fg="white")
        self.favorite_quote_button.pack(side=tk.LEFT, padx=5)
        # View Favorite Quotes window
        self.favorite_quotes_window_button = tk.Button(self.button_frame, text="View Favorite Quotes", command=self.favorite_quotes_window, bg="purple", fg="white")
        self.favorite_quotes_window_button.pack(side=tk.LEFT, padx=5)
        # Exit Button
        self.exit_button = tk.Button(self.button_frame, text="X", command=self.exit_application, bg="red", fg="white")
        self.exit_button.pack(side=tk.LEFT, padx=5)
        # Upload Blue Jellyfish
        self.image = Image.open("Blue Jellyfish.jpg")
        self.photo = ImageTk.PhotoImage(self.image)
        self.image_label = tk.Label(self.root, image=self.photo)
        self.image_label.image = self.photo
        self.image_label.pack()
        # Image Title
        self.blue_jellyfish_text_label = tk.Label(self.root, text="Blue Jellyfish Image", bg="white", fg="blue")
        self.blue_jellyfish_text_label.pack()

    """Module 2: Pulls text file and generates Quotes, and defines first window buttons"""
    # Generate Quote from Text File
    def update_quote(self):
        try:
            # Open Text File
            with open('Positive Quote List.txt', 'r') as file:
                # Reads and strips text file
                quotes = file.readlines()
                quotes = [quote.strip() for quote in quotes]
                # Sets parameters for allowed characters
                quotes = [quote for quote in quotes if quote and not any(char in quote for char in [';', ':', '|', '&'])]
                # Generates random quote if quotes are present
                if quotes:
                    quote = random.choice(quotes)
                    self.daily_quote_text.delete(1.0, tk.END)
                    self.daily_quote_text.insert(tk.END, quote)
                # Generates an error code if no quotes
                else:
                    self.daily_quote_text.delete(1.0, tk.END)
                    self.daily_quote_text.insert(tk.END, "No quotes available.")
        # Displays error message if quote uses forbidden characters
        except Exception as e:
            self.daily_quote_text.delete(1.0, tk.END)
            self.daily_quote_text.insert(tk.END, f"Error retrieving quote: {e}")

    # Displays popup confirming the favorite
    def favorite_quote(self):
        print("Quote favorited!")

    def favorite_quotes_window(self):
        self.root.destroy()
        root = tk.Tk()
        app = FavoriteQuotesApp(root)
        root.mainloop()    

    # Displays popup to confirm exit
    def exit_application(self):
        if messagebox.askyesno("Confirm Exit", "Are you sure you want to exit?"):
            self.root.destroy()

"""Module 3: Second Window Favorite Quotes"""
# Favorite Quotes Window
class FavoriteQuotesApp:
    def __init__(self, root):
        self.root = root
        # Window Title
        self.root.title("Favorite Quotes")
        self.favorite_quotes_label = tk.Label(self.root, text="Favorite Quotes", font=("Arial", 24, "bold"))
        self.favorite_quotes_label.pack(pady=10)
        # Message
        self.important_text_label = tk.Label(self.root, text="Highlight quote with cursor to delete.", fg="red")
        self.important_text_label.pack()
        # Text Box
        self.favorite_quote_text = tk.Text(self.root, height=10, width=50, wrap=tk.WORD)
        self.favorite_quote_text.pack()
        
       
        # Moves Quotes from one Window to the next
        try:
            with open('favorite_quotes.txt', 'r') as file:
                favorite_quotes = file.readlines()
                self.favorite_quote_text.delete(1.0, tk.END)
                self.favorite_quote_text.insert(tk.END, "".join(favorite_quotes))
        # Error message if quote can't be moved.
        except Exception as e:
            messagebox.showerror("Error", str(e))
            
        # Button Frame
        self.button_frame = tk.Frame(self.root)
        self.button_frame.pack(pady=10)
        # Remove Quotes button
        self.remove_quote_button = tk.Button(self.button_frame, text="Remove Quote", command=self.remove_quote, bg="orange", fg="white")
        self.remove_quote_button.pack(side=tk.LEFT, padx=5)
        # Back Button to go back
        self.back_button = tk.Button(self.button_frame, text="Main Menu", command=self.back, bg="purple", fg="white")
        self.back_button.pack(side=tk.LEFT, padx=5)
        # Exit Button
        self.exit_button = tk.Button(self.button_frame, text="X", command=self.exit_application, bg="red", fg="white")
        self.exit_button.pack(side=tk.LEFT, padx=5)
        # Purple Jellyfish
        self.image2 = Image.open("Purple Jellyfish.jpg")
        self.photo2 = ImageTk.PhotoImage(self.image2)
        # Image Label
        self.image2_label = tk.Label(self.root, image=self.photo2)
        self.image2_label.image = self.photo2
        self.image2_label.pack()
        # Image Title
        self.purple_jellyfish_text_label = tk.Label(self.root, text="Purple Jellyfish Image", bg="white", fg="purple")
        self.purple_jellyfish_text_label.pack()


    """Module 4: Defines buttons for second window"""
    # Remove Quote Button Definition
    def remove_quote(self):
        try:
            quote_to_remove = self.favorite_quote_text.selection_get()
            if quote_to_remove:
                self.favorite_quote_text.delete("sel.first", "sel.last")
                with open('favorite_quotes.txt', 'w') as file:
                    file.write(self.favorite_quote_text.get(1.0, tk.END))
                # Confirmation message
                messagebox.showinfo("Quote Removed", "Quote has been removed from your favorites.")
            # Error if quote was not highlighted to delete
            else:
                messagebox.showerror("Error", "Please highlight the code you want to delete.")
        except Exception as e:
            messagebox.showerror("Error", str(e))
        
    # Defines Back Button
    def back(self):
        self.root.destroy()
        root = tk.Tk()
        app = PositiveQuotesApp(root)
        root.mainloop()

    # Defines Exit Button
    def exit_application(self):
        if messagebox.askyesno("Confirm Exit", "Are you sure you want to exit?"):
            self.root.destroy()

# Defines Add to Favorite Quotes Button
def add_quote_to_favorite_quotes(daily_quote_text):
    quote = daily_quote_text.get(1.0, tk.END).strip()
    if quote:
        with open('favorite_quotes.txt', 'a') as file:
            file.write(quote + "\n")
        # Confirmation popup
        messagebox.showinfo("Quote Added", "Quote has been added to your favorite quotes.")
    # Error code if code can't be transferred
    else:
        messagebox.showerror("Error", "No quote selected.")

# Defines exit button
def exit_application(root):
    if messagebox.askyesno("Confirm Exit", "Are you sure you want to exit?"):
        root.destroy()

# Calls Function
if __name__ == "__main__":
    root = tk.Tk()
    app = PositiveQuotesApp(root)
    root.mainloop()
